# Distribuir Factura C — versión 1.5.1

## Archivos

- `arca-factura-c-1.5.1-compartir.zip`: extensión dentro de `extension/` e instrucciones de instalación. Enviar a usuarios que acepten instalarla como extensión descomprimida.
- `arca-factura-c-1.5.1-chrome-store.zip`: sólo archivos de ejecución; `manifest.json` está en la raíz. Este es el ZIP que se sube al panel de desarrollador de Chrome Web Store.
- `arca-factura-c-1.5.1-publicacion.zip`: ficha sugerida, política de privacidad para completar/publicar, capturas y esta guía. No subir este ZIP como extensión.
- `arca-factura-c-1.5.1-fuentes.zip`: código, pruebas y herramientas de empaquetado.

El código de facturación es el mismo de 1.5.0, validado por el usuario. Cambian el ícono, la versión y la descripción. El ícono es una adaptación generada a partir de la referencia adjunta, no una copia exacta del archivo original. Se conserva el original de la adaptación en `assets/icon-source.png` dentro del paquete de fuentes. Confirmar los derechos sobre la referencia antes de distribuir.

## Compartir sin tienda

1. Enviar el ZIP `compartir`.
2. El destinatario lo extrae en una carpeta permanente.
3. En `chrome://extensions`, activa Modo de desarrollador, pulsa Cargar descomprimida y selecciona `extension`.
4. Ancla el ícono desde el menú de extensiones de Chrome.
5. Abre su propia sesión RCEL, selecciona su contribuyente y deja el menú principal abierto. No se comparte ninguna sesión ni Clave Fiscal con el paquete.

Las actualizaciones de una instalación descomprimida son manuales. No eliminar la carpeta después de instalar. Un archivo `.crx` enviado por correo no es una alternativa universal de instalación, especialmente en Windows y macOS. Para usuarios finales sin modo de desarrollador, distribuir mediante Chrome Web Store.

## Subir a Chrome Web Store

1. Registrar/configurar la cuenta de desarrollador en el panel oficial. Google puede exigir verificaciones y una tarifa de registro; revisar el importe actual allí.
2. Crear un nuevo elemento y subir `arca-factura-c-1.5.1-chrome-store.zip`.
3. Completar la ficha usando `FICHA-TIENDA.md`. Elegir categoría, idioma español, países y visibilidad. Si se quiere compartir sólo por enlace, evaluar la opción no listada disponible en el panel.
4. Subir el ícono de 128 px y al menos una captura. Las capturas incluidas muestran el interfaz real del panel, renderizada localmente con las APIs de Chrome simuladas con un importe de ejemplo, sin sesión fiscal ni comprobantes reales.
5. Completar nombre/contacto del responsable en `PRIVACIDAD.html`, revisar el texto y alojarlo en una URL HTTPS pública. Pegar esa URL en el campo de política de privacidad. El archivo local no reemplaza una URL pública.
6. Completar las prácticas de privacidad y justificaciones de permisos con las notas de `FICHA-TIENDA.md`. Verificar que la declaración refleje los datos fiscales procesados localmente, aunque no se envíen al desarrollador.
7. Incluir instrucciones de prueba para el revisor: requiere cuenta propia/autorizada de ARCA, servicio RCEL y punto de venta habilitado. No incluir tu Clave Fiscal, cookies ni credenciales personales en la ficha o en el paquete. Explicar que emitir genera un comprobante fiscal real y que existe modo de revisión sin emisión.
8. Revisar todo y enviar a revisión de Google. El paquete está preparado para cargar; no implica aprobación ni publicación automática.

No se ha publicado ni registrado una cuenta por vos. Todavía faltan identidad/contacto del responsable, URL pública de privacidad, completar el formulario del panel y superar la revisión de Google. No se incluyó una licencia que ceda derechos de tu código: si vas a distribuirlo públicamente, elegí los términos que correspondan.

## Mantenimiento

Para actualizar una extensión ya publicada, subir un ZIP con versión mayor al mismo elemento del panel. Conservar el mismo elemento mantiene su ID. No crear una ficha nueva en cada actualización. La extensión descomprimida y la de tienda pueden tener IDs y preferencias distintos; evitar tener ambas activas durante la facturación.

Para reconstruir los paquetes: `python scripts/package_release.py`. Para regenerar tamaños del ícono: `python scripts/build_icons.py assets/icon-source.png` (requiere Pillow). `npm test` verifica el código; el empaquetador comprueba los recursos del manifiesto y rechaza archivos sensibles.

## Fuentes oficiales consultadas

- Publicación: https://developer.chrome.com/docs/webstore/publish
- Imágenes: https://developer.chrome.com/docs/webstore/images
- Privacidad: https://developer.chrome.com/docs/webstore/cws-dashboard-privacy
- Instalación alternativa y límites de CRX: https://developer.chrome.com/docs/extensions/how-to/distribute/install-extensions
