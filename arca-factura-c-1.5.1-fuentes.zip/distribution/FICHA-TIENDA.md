# Textos sugeridos para la ficha

**Nombre:** ARCA · Preparar Factura C

**Descripción breve:** Asistente independiente para Factura C en RCEL: preparación, emisión opcional y aviso. No es una extensión oficial de ARCA.

**Descripción completa:**

Prepará una Factura C desde cualquier pestaña de Chrome usando tu sesión abierta en Comprobantes en Línea (RCEL).

Ingresá el importe en formato argentino. La extensión encuentra la pestaña RCEL y completa: consumidor final, concepto Productos y Servicios, condición Contado, una línea Servicios y las fechas del día en Argentina.

Podés detenerte en la revisión final o activar expresamente «No aguardar confirmación» para emitir automáticamente. Después de una emisión reconocida, muestra una notificación con el importe, vuelve al menú principal y deja el importe vacío. La preferencia de emisión se conserva hasta que la cambies.

Si hay varias pestañas RCEL, elegís cuál usar. Trabaja en segundo plano y ofrece un botón para ir a RCEL. Requiere una sesión vigente, contribuyente seleccionado y un único punto de venta disponible para la selección automática. No completa datos fiscales adicionales que el portal exija y no reemplaza asesoramiento contable.

No solicita ni almacena tu Clave Fiscal. No envía datos a servidores del desarrollador, no contiene publicidad ni analítica. Los datos de la ejecución se procesan en tu navegador y se introducen en el servicio oficial de ARCA según tus instrucciones. La preferencia se guarda localmente.

Herramienta independiente, sin afiliación, respaldo ni carácter oficial de ARCA o AFIP. Los cambios del portal pueden requerir actualizar la extensión.

## Propósito único

Automatizar la preparación y, con autorización explícita del usuario, la emisión de una Factura C en su sesión RCEL, notificando el resultado y regresando al menú.

## Justificación de permisos

- `scripting`: leer controles y completar los formularios de la pestaña RCEL elegida. Ejecutar el clic final sólo en el modo autorizado; aceptar el mensaje específico de confirmación de esa emisión.
- `storage`: guardar la preferencia de emisión en almacenamiento local y el importe, fechas y estado de ejecución en almacenamiento de sesión para continuar cuando el panel está cerrado.
- `notifications`: avisar del comprobante generado y su importe mientras el usuario está en otra pestaña.
- `https://fe.afip.gob.ar/*` y `https://fe.arca.gob.ar/*`: descubrir pestañas del servicio y operar RCEL en segundo plano sin solicitar acceso al correo ni a todos los sitios. El código restringe la ejecución a `/rcel/`; Chrome concede el permiso por host.

**Código remoto:** no se descarga ni ejecuta código de terceros como parte de la extensión; todos los scripts están incluidos en el ZIP. Se interactúa con el sitio RCEL abierto por el usuario.

## Notas para las declaraciones de datos

No afirmar «no procesa datos»: lee contenido de las pantallas fiscales y procesa importes/fechas localmente. No dispone de backend, analítica ni venta de datos. No lee ni almacena cookies, tokens o Clave Fiscal. En la pestaña RCEL puede observar datos personales/fiscales presentes en el formulario y títulos/URL de pestañas autorizadas. Los datos se utilizan exclusivamente para la función solicitada y se introducen en ARCA. La notificación muestra el importe al sistema operativo.

Revisar las categorías aplicables del formulario vigente de Google y completar las certificaciones personalmente. No confundir «sin transmisión al desarrollador» con «sin acceso a información del usuario».

## Material gráfico

- Ícono: `store-icon-128.png`.
- `screenshot-manual-1280x800.png`: interfaz real del panel, renderizada localmente con las APIs de Chrome simuladas en modo revisión, importe de ejemplo.
- `screenshot-automatic-1280x800.png`: interfaz real del panel, renderizada localmente con las APIs de Chrome simuladas con emisión automática elegida. No se emitió ningún comprobante para la captura.

## Pendientes del titular

Identidad del publicador, correo de soporte, URL pública de privacidad, categoría, distribución y términos/licencia. La revisión o aprobación de Google no está garantizada.
