"""Export Chrome icon sizes from a supplied PNG. Requires Pillow."""
from pathlib import Path
from PIL import Image
import sys
root = Path(__file__).resolve().parents[1]
source = Path(sys.argv[1]) if len(sys.argv) > 1 else root / 'assets/icon-source.png'
image = Image.open(source).convert('RGBA')
if image.width != image.height:
    raise SystemExit('El ícono fuente debe ser cuadrado.')
output = root / 'extension/icons'
output.mkdir(exist_ok=True)
for size in (16, 32, 48, 64, 128):
    image.resize((size, size), Image.Resampling.LANCZOS).save(output / f'icon-{size}.png')
image.resize((128, 128), Image.Resampling.LANCZOS).save(root / 'extension/icon.png')
