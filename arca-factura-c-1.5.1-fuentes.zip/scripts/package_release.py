"""Create distribution ZIPs without browser profiles, credentials or dev artifacts."""
from pathlib import Path
import hashlib
import json
import zipfile
import struct
root = Path(__file__).resolve().parents[1]
extension = root / 'extension'
manifest = json.loads((extension / 'manifest.json').read_text())
version = manifest['version']
out = root / 'dist'
out.mkdir(exist_ok=True)
resources = [manifest['background']['service_worker'], manifest['action']['default_popup']]
resources += list(manifest['icons'].values()) + list(manifest['action']['default_icon'].values())
for name in resources:
    assert (extension / name).is_file(), name
for size, name in manifest['icons'].items():
    blob = (extension / name).read_bytes()
    assert blob[:8] == b'\x89PNG\r\n\x1a\n'
    assert struct.unpack('>II', blob[16:24]) == (int(size), int(size))
files = sorted(p for p in extension.rglob('*') if p.is_file())
assert all(p.suffix in ('.js', '.json', '.html', '.css', '.png') for p in files)
assert not any(p.is_symlink() for p in files)
assert not any(x in p.name.lower() for p in files for x in ('.pem', '.key', '.env', 'cookie', 'credential'))
install = '''INSTALACIÓN\n\nExtraer este ZIP. Abrir chrome://extensions, activar Modo de desarrollador, pulsar Cargar descomprimida y elegir extension. Mantener esa carpeta. Anclar el ícono desde el menú de extensiones.\n\nAbrir la propia sesión RCEL, elegir contribuyente y dejar el menú principal. Desde cualquier pestaña, abrir la extensión e ingresar importe. La opción No aguardar confirmación emite realmente; dejarla desmarcada para revisar antes de emitir.\n\nHerramienta independiente, no oficial de ARCA. No compartir Clave Fiscal. Cada destinatario utiliza su propia sesión y autorización. Actualizaciones manuales reemplazando archivos y pulsando Recargar.\n'''

def write_zip(label, members, extra=None):
    target = out / f'arca-factura-c-{version}-{label}.zip'
    with zipfile.ZipFile(target, 'w', zipfile.ZIP_DEFLATED) as archive:
        for path, name in members:
            archive.write(path, name)
        for name, value in (extra or {}).items():
            archive.writestr(name, value)
    with zipfile.ZipFile(target) as archive:
        assert archive.testzip() is None
    return target

packages = []
packages.append(write_zip('chrome-store', [(p, p.relative_to(extension).as_posix()) for p in files]))
packages.append(write_zip('compartir', [(p, 'extension/' + p.relative_to(extension).as_posix()) for p in files], {'INSTALAR.txt': install}))
publication = sorted(p for p in (root / 'distribution').rglob('*') if p.is_file())
packages.append(write_zip('publicacion', [(p, p.relative_to(root / 'distribution').as_posix()) for p in publication]))
sources = [(p, p.relative_to(root).as_posix()) for folder in ['extension', 'tests', 'scripts', 'assets', 'distribution'] for p in sorted((root / folder).rglob('*')) if p.is_file() and '__pycache__' not in p.parts]
sources += [(root / name, name) for name in ['README.md', 'package.json']]
packages.append(write_zip('fuentes', sources))
(out / 'SHA256SUMS.txt').write_text(''.join(f'{hashlib.sha256(p.read_bytes()).hexdigest()}  {p.name}\n' for p in packages))
print('\n'.join(str(p) for p in packages))
